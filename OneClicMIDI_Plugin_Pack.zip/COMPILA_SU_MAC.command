#!/bin/bash
cd "$(dirname "$0")"
echo "========================================================"
echo "  ONE CLIC MIDI (By BR1) - AUTO-BUILDER MACOS (VST3 & AU)"
echo "========================================================"
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release --target OneClicMIDI_VST3
cmake --build build --config Release --target OneClicMIDI_AU
echo "========================================================"
echo "  COMPILAZIONE COMPLETATA!"
echo "========================================================"
read -p "Premi Invio per chiudere..."
