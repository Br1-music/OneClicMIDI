@echo off
title Compilazione Automatica OneClicMIDI (By BR1) - VST3
echo ========================================================
echo   ONE CLIC MIDI (By BR1) - AUTO-BUILDER WINDOWS VST3
echo ========================================================
echo.
cd /d "%~dp0"
echo [1/2] Configurazione CMake e download automatico JUCE 7...
cmake -B build -DCMAKE_BUILD_TYPE=Release
if %errorlevel% neq 0 (
    echo.
    echo [ERRORE] Assicurati di avere installato CMake e Visual Studio C++ Build Tools.
    pause
    exit /b %errorlevel%
)
echo.
echo [2/2] Compilazione del plugin OneClicMIDI.vst3 in corso...
cmake --build build --config Release --target OneClicMIDI_VST3
echo.
echo ========================================================
echo   COMPILAZIONE COMPLETATA CON SUCCESSO!
echo   Il tuo plugin si trova in:
echo   build\OneClicMIDI_artefacts\Release\VST3\OneClicMIDI.vst3
echo ========================================================
pause
