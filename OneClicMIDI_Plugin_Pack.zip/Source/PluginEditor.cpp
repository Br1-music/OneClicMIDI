#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <BinaryData.h>
#include <cmath>

OneClicMIDIAudioProcessorEditor::OneClicMIDIAudioProcessorEditor (OneClicMIDIAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    setLookAndFeel (&modernLookAndFeel);
    setSize (460, 350);

    if (audioProcessor.customLogoPath.isNotEmpty())
    {
        juce::File customFile (audioProcessor.customLogoPath);
        if (customFile.existsAsFile())
            brandLogo = juce::ImageFileFormat::loadFrom (customFile);
    }

    if (!brandLogo.isValid())
    {
        brandLogo = juce::ImageCache::getFromMemory (BinaryData::logo_png, BinaryData::logo_pngSize);
    }

    presetSelector.addItemList ({
        "Melodia & Voce (Lead / Vocal)",
        "Bassline & 808 (Sub / Bass)",
        "Accordi & Synth (Polifonico)",
        "Drum Loop (Kick / Snare / Hat)",
        "Universal Auto-Detect"
    }, 1);
    presetSelector.setJustificationType (juce::Justification::centred);
    addAndMakeVisible (presetSelector);

    presetAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (
        audioProcessor.apvts, "PRESET_ID", presetSelector);

    startTimerHz (30);
}

OneClicMIDIAudioProcessorEditor::~OneClicMIDIAudioProcessorEditor()
{
    setLookAndFeel (nullptr);
}

bool OneClicMIDIAudioProcessorEditor::isInterestedInFileDrag (const juce::StringArray& files)
{
    for (const auto& f : files)
    {
        if (f.endsWithIgnoreCase (".wav") || f.endsWithIgnoreCase (".aif") ||
            f.endsWithIgnoreCase (".aiff") || f.endsWithIgnoreCase (".flac"))
            return true;
    }
    return false;
}

void OneClicMIDIAudioProcessorEditor::fileDragEnter (const juce::StringArray&, int, int)
{
    isDraggingOver = true;
    repaint();
}

void OneClicMIDIAudioProcessorEditor::fileDragExit (const juce::StringArray&)
{
    isDraggingOver = false;
    repaint();
}

void OneClicMIDIAudioProcessorEditor::filesDropped (const juce::StringArray& files, int, int)
{
    isDraggingOver = false;
    if (files.size() > 0)
        processSelectedWavFile (juce::File (files[0]));
}

void OneClicMIDIAudioProcessorEditor::mouseExit (const juce::MouseEvent&)
{
    isHoveringButton = false;
    repaint();
}

void OneClicMIDIAudioProcessorEditor::mouseDown (const juce::MouseEvent& event)
{
    auto pos = event.getPosition();

    if (logoBounds.contains (pos))
    {
        loadCustomLogoFromFile();
        return;
    }

    auto center = centerButtonBounds.getCentre().toFloat();
    if (center.getDistanceFrom (pos.toFloat()) <= 72.0f)
    {
        openWavAndConvertOneClick();
    }
}

void OneClicMIDIAudioProcessorEditor::openWavAndConvertOneClick()
{
    wavFileChooser = std::make_unique<juce::FileChooser> (
        "Seleziona un file WAV da convertire in MIDI",
        juce::File::getSpecialLocation (juce::File::userDesktopDirectory),
        "*.wav;*.aif;*.aiff;*.flac");

    auto flags = juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles;

    wavFileChooser->launchAsync (flags, [this] (const juce::FileChooser& chooser)
    {
        juce::File chosen = chooser.getResult();
        if (chosen.existsAsFile())
            processSelectedWavFile (chosen);
    });
}

void OneClicMIDIAudioProcessorEditor::processSelectedWavFile (const juce::File& wavFile)
{
    juce::File outMidi = wavFile.getSiblingFile (wavFile.getFileNameWithoutExtension() + "_OneClicMIDI.mid");
    conversionSuccess = audioProcessor.convertAudioFileToMidi (wavFile, outMidi);
    repaint();
}

void OneClicMIDIAudioProcessorEditor::loadCustomLogoFromFile()
{
    logoFileChooser = std::make_unique<juce::FileChooser> (
        "Seleziona il tuo Logo (PNG o JPG)",
        juce::File::getSpecialLocation (juce::File::userDesktopDirectory),
        "*.png;*.jpg;*.jpeg");

    auto flags = juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles;

    logoFileChooser->launchAsync (flags, [this] (const juce::FileChooser& chooser)
    {
        juce::File chosenFile = chooser.getResult();
        if (chosenFile.existsAsFile())
        {
            juce::Image loadedImg = juce::ImageFileFormat::loadFrom (chosenFile);
            if (loadedImg.isValid())
            {
                brandLogo = loadedImg;
                audioProcessor.customLogoPath = chosenFile.getFullPathName();
                repaint();
            }
        }
    });
}

void OneClicMIDIAudioProcessorEditor::timerCallback()
{
    pulsePhase += 0.08f;
    if (pulsePhase > juce::MathConstants<float>::twoPi)
        pulsePhase -= juce::MathConstants<float>::twoPi;

    auto mousePos = getMouseXYRelative();
    isHoveringButton = (centerButtonBounds.getCentre().toFloat().getDistanceFrom (mousePos.toFloat()) <= 72.0f);

    repaint();
}

void OneClicMIDIAudioProcessorEditor::paint (juce::Graphics& g)
{
    // 1. Sfondo moderno con gradiente radiale scuro (#171923 -> #0d0e13)
    juce::ColourGradient bgGrad (
        juce::Colour (0xff171923), static_cast<float>(getWidth()) * 0.5f, 180.0f,
        juce::Colour (0xff0d0e13), 0.0f, 0.0f, true);
    g.setGradientFill (bgGrad);
    g.fillAll();

    // 2. Header Minimalista: Logo + Titolo "ONE CLIC MIDI" + Badge "By BR1"
    if (brandLogo.isValid())
    {
        g.drawImageWithin (brandLogo,
                           logoBounds.getX(), logoBounds.getY(),
                           logoBounds.getWidth(), logoBounds.getHeight(),
                           juce::RectanglePlacement::centred | juce::RectanglePlacement::onlyReduceInSize);
    }

    g.setColour (juce::Colours::white);
    g.setFont (juce::Font (21.0f, juce::Font::bold));
    g.drawText ("ONE CLIC MIDI", 78, 22, 200, 38, juce::Justification::centredLeft);

    juce::Rectangle<float> br1Badge (272.0f, 28.0f, 68.0f, 26.0f);
    g.setColour (juce::Colour (0x22ff6b00));
    g.fillRoundedRectangle (br1Badge, 7.0f);
    g.setColour (juce::Colour (0xffff6b00));
    g.drawRoundedRectangle (br1Badge, 7.0f, 1.3f);
    g.setFont (juce::Font (13.0f, juce::Font::bold));
    g.drawText ("By BR1", br1Badge.toNearestInt(), juce::Justification::centred);

    g.setColour (juce::Colour (0xff1f222e));
    g.fillRect (24, 74, getWidth() - 48, 1);

    // 3. Grande Pulsante Centrale Circolare "WAV -> MIDI" (Cliccabile + Drag & Drop)
    bool isHighlighted = conversionSuccess || isDraggingOver;
    auto btnArea = centerButtonBounds.toFloat();
    auto center = btnArea.getCentre();

    if (isHighlighted)
    {
        float glowRadius = 80.0f + (std::sin (pulsePhase) * 3.5f);
        juce::ColourGradient glow (
            juce::Colour (0x55ff6b00), center.x, center.y,
            juce::Colour (0x00ff6b00), center.x + glowRadius, center.y, true);
        g.setGradientFill (glow);
        g.fillEllipse (center.x - glowRadius, center.y - glowRadius, glowRadius * 2.0f, glowRadius * 2.0f);
    }

    g.setColour (isHighlighted ? juce::Colour (0xffff6b00) : juce::Colour (0xff2c3040));
    g.drawEllipse (btnArea.reduced (2.0f), 2.5f);

    juce::ColourGradient btnGrad (
        isHighlighted ? juce::Colour (0xffff7b1c) : (isHoveringButton ? juce::Colour (0xff232634) : juce::Colour (0xff1b1d28)),
        center.x, btnArea.getY(),
        isHighlighted ? juce::Colour (0xffd95300) : juce::Colour (0xff13151d),
        center.x, btnArea.getBottom(), false);
    g.setGradientFill (btnGrad);
    g.fillEllipse (btnArea.reduced (7.0f));

    // Icona Note MIDI vettoriale dentro il pulsante circolare
    g.setColour (isHighlighted ? juce::Colours::white : juce::Colour (0xffff6b00));
    float iconY = center.y - 22.0f;
    g.fillRoundedRectangle (center.x - 22.0f, iconY,      16.0f, 6.0f, 3.0f);
    g.fillRoundedRectangle (center.x - 4.0f,  iconY - 7.0f, 18.0f, 6.0f, 3.0f);
    g.fillRoundedRectangle (center.x + 8.0f,  iconY + 5.0f, 15.0f, 6.0f, 3.0f);

    g.setColour (isHighlighted ? juce::Colours::white : juce::Colour (0xffdadfe8));
    g.setFont (juce::Font (13.0f, juce::Font::bold));
    juce::String mainLabel = isDraggingOver ? "RILASCIA IL WAV"
                           : (conversionSuccess ? "MIDI SALVATO!" : "WAV -> MIDI");
    g.drawText (mainLabel,
                btnArea.toNearestInt().withTrimmedTop (64).withHeight (22),
                juce::Justification::centred);

    g.setColour (isHighlighted ? juce::Colour (0xffffeedd) : juce::Colour (0xff8a90a2));
    g.setFont (juce::Font (11.0f, juce::Font::plain));
    juce::String subLabel = conversionSuccess
                          ? (juce::String (audioProcessor.lastDetectedNoteCount.load()) + " NOTE ESTRATTE")
                          : "1 CLIC O TRASCINA";
    g.drawText (subLabel,
                btnArea.toNearestInt().withTrimmedTop (84).withHeight (18),
                juce::Justification::centred);

    // 4. Barra di stato sottile (5 px) in basso
    float barWidth = static_cast<float>(getWidth() - 80);
    float barX = 40.0f;
    float barY = 316.0f;
    g.setColour (juce::Colour (0xff1b1e29));
    g.fillRoundedRectangle (barX, barY, barWidth, 5.0f, 2.5f);

    float progress = audioProcessor.conversionProgress.load();
    if (progress > 0.01f)
    {
        float activeW = barWidth * juce::jlimit (0.05f, 1.0f, progress);
        juce::ColourGradient meterGrad (
            juce::Colour (0xffff6b00), barX, barY,
            juce::Colour (0xffffaa44), barX + barWidth, barY, false);
        g.setGradientFill (meterGrad);
        g.fillRoundedRectangle (barX, barY, activeW, 5.0f, 2.5f);
    }
}

void OneClicMIDIAudioProcessorEditor::resized()
{
    presetSelector.setBounds (40, 90, getWidth() - 80, 36);
}
