#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class ModernMidiLookAndFeel : public juce::LookAndFeel_V4
{
public:
    ModernMidiLookAndFeel()
    {
        setColour (juce::ComboBox::backgroundColourId, juce::Colour (0xff191b24));
        setColour (juce::ComboBox::textColourId, juce::Colours::white);
        setColour (juce::ComboBox::outlineColourId, juce::Colour (0xff2d3142));
        setColour (juce::ComboBox::arrowColourId, juce::Colour (0xffff6b00));

        setColour (juce::PopupMenu::backgroundColourId, juce::Colour (0xff191b24));
        setColour (juce::PopupMenu::textColourId, juce::Colours::white);
        setColour (juce::PopupMenu::highlightedBackgroundColourId, juce::Colour (0xffff6b00));
        setColour (juce::PopupMenu::highlightedTextColourId, juce::Colours::white);
    }

    void drawComboBox (juce::Graphics& g, int width, int height, bool,
                       int, int, int, int, juce::ComboBox& box) override
    {
        auto bounds = juce::Rectangle<float> (0.0f, 0.0f, static_cast<float>(width), static_cast<float>(height));
        g.setColour (juce::Colour (0xff191b24));
        g.fillRoundedRectangle (bounds, 10.0f);

        g.setColour (box.hasKeyboardFocus (true) ? juce::Colour (0xffff6b00) : juce::Colour (0xff2e3244));
        g.drawRoundedRectangle (bounds.reduced (0.5f), 10.0f, 1.2f);

        juce::Path arrow;
        float cx = static_cast<float>(width - 20);
        float cy = static_cast<float>(height) * 0.5f;
        arrow.startNewSubPath (cx - 5.0f, cy - 2.5f);
        arrow.lineTo (cx, cy + 3.0f);
        arrow.lineTo (cx + 5.0f, cy - 2.5f);

        g.setColour (juce::Colour (0xffff6b00));
        g.strokePath (arrow, juce::PathStrokeType (2.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    }

    juce::Font getComboBoxFont (juce::ComboBox&) override
    {
        return juce::Font (14.5f, juce::Font::bold);
    }
};

class OneClicMIDIAudioProcessorEditor : public juce::AudioProcessorEditor,
                                        public juce::FileDragAndDropTarget,
                                        private juce::Timer
{
public:
    explicit OneClicMIDIAudioProcessorEditor (OneClicMIDIAudioProcessor&);
    ~OneClicMIDIAudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;
    void timerCallback() override;
    void mouseDown (const juce::MouseEvent& event) override;
    void mouseExit (const juce::MouseEvent& event) override;

    // Supporto Drag & Drop diretto di qualsiasi file .WAV sulla finestra del plugin
    bool isInterestedInFileDrag (const juce::StringArray& files) override;
    void fileDragEnter (const juce::StringArray& files, int x, int y) override;
    void fileDragExit (const juce::StringArray& files) override;
    void filesDropped (const juce::StringArray& files, int x, int y) override;

private:
    void openWavAndConvertOneClick();
    void processSelectedWavFile (const juce::File& wavFile);
    void loadCustomLogoFromFile();

    OneClicMIDIAudioProcessor& audioProcessor;
    ModernMidiLookAndFeel modernLookAndFeel;

    juce::Image brandLogo;
    juce::Rectangle<int> logoBounds { 24, 20, 42, 42 };
    juce::Rectangle<int> centerButtonBounds { 160, 148, 140, 140 };

    bool isHoveringButton = false;
    bool isDraggingOver = false;
    bool conversionSuccess = false;
    float pulsePhase = 0.0f;

    std::unique_ptr<juce::FileChooser> wavFileChooser;
    std::unique_ptr<juce::FileChooser> logoFileChooser;

    juce::ComboBox presetSelector;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> presetAttachment;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (OneClicMIDIAudioProcessorEditor)
};
