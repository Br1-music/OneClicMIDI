#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>
#include <algorithm>
#include <map>

OneClicMIDIAudioProcessor::OneClicMIDIAudioProcessor()
    : AudioProcessor (BusesProperties()
                      .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                      .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "PARAMETERS", createParameterLayout())
{
    presetNames = {
        "Melodia & Voce (Lead / Vocal)",
        "Bassline & 808 (Sub / Bass)",
        "Accordi & Synth (Polifonico)",
        "Drum Loop (Kick / Snare / Hat)",
        "Universal Auto-Detect"
    };
    analysisRingBuffer.resize (2048, 0.0f);
}

juce::AudioProcessorValueTreeState::ParameterLayout OneClicMIDIAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    params.push_back (std::make_unique<juce::AudioParameterChoice> (
        "PRESET_ID", "Detection Mode",
        juce::StringArray {
            "Melodia & Voce (Lead / Vocal)",
            "Bassline & 808 (Sub / Bass)",
            "Accordi & Synth (Polifonico)",
            "Drum Loop (Kick / Snare / Hat)",
            "Universal Auto-Detect"
        }, 0));

    return { params.begin(), params.end() };
}

void OneClicMIDIAudioProcessor::setCurrentProgram (int index)
{
    if (index >= 0 && index < presetNames.size())
    {
        currentPresetIndex = index;
        if (auto* param = apvts.getParameter ("PRESET_ID"))
            param->setValueNotifyingHost (param->convertTo0to1 (static_cast<float>(index)));
    }
}

void OneClicMIDIAudioProcessor::prepareToPlay (double sampleRate, int)
{
    currentSampleRate = sampleRate;
    currentLiveNote = -1;
    std::fill (analysisRingBuffer.begin(), analysisRingBuffer.end(), 0.0f);
    ringWritePos = 0;
}

bool OneClicMIDIAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    return layouts.getMainOutputChannelSet() == juce::AudioChannelSet::stereo()
        || layouts.getMainOutputChannelSet() == juce::AudioChannelSet::mono();
}

int OneClicMIDIAudioProcessor::detectMonophonicMidiNote (const float* samples, int numSamples,
                                                         double sampleRate, float minFreq, float maxFreq,
                                                         float& outConfidence)
{
    outConfidence = 0.0f;
    if (numSamples < 256 || sampleRate <= 0.0)
        return -1;

    // Calcolo energia RMS
    float sumSq = 0.0f;
    for (int i = 0; i < numSamples; ++i)
        sumSq += samples[i] * samples[i];
    float rms = std::sqrt (sumSq / static_cast<float>(numSamples));
    if (rms < 0.012f)
        return -1;

    int halfLen = numSamples / 2;
    int minLag = std::max (2, static_cast<int>(sampleRate / maxFreq));
    int maxLag = std::min (halfLen - 1, static_cast<int>(sampleRate / minFreq));
    if (minLag >= maxLag)
        return -1;

    // Algoritmo YIN (Cumulative Mean Normalized Difference)
    std::vector<float> diff (maxLag + 1, 0.0f);
    std::vector<float> cmnd (maxLag + 1, 1.0f);

    for (int tau = 1; tau <= maxLag; ++tau)
    {
        float d = 0.0f;
        for (int i = 0; i < halfLen; ++i)
        {
            float delta = samples[i] - samples[i + tau];
            d += delta * delta;
        }
        diff[tau] = d;
    }

    float runningSum = 0.0f;
    for (int tau = 1; tau <= maxLag; ++tau)
    {
        runningSum += diff[tau];
        cmnd[tau] = (runningSum > 1e-9f) ? (diff[tau] * static_cast<float>(tau) / runningSum) : 1.0f;
    }

    int bestTau = -1;
    const float yinThreshold = 0.18f;

    for (int tau = minLag; tau <= maxLag; ++tau)
    {
        if (cmnd[tau] < yinThreshold)
        {
            while (tau + 1 <= maxLag && cmnd[tau + 1] < cmnd[tau])
                ++tau;
            bestTau = tau;
            break;
        }
    }

    if (bestTau < 0)
    {
        float minVal = 1.0f;
        for (int tau = minLag; tau <= maxLag; ++tau)
        {
            if (cmnd[tau] < minVal)
            {
                minVal = cmnd[tau];
                bestTau = tau;
            }
        }
        if (minVal > 0.38f)
            return -1;
    }

    // Interpolazione parabolica per precisione sub-campione
    float refinedTau = static_cast<float>(bestTau);
    if (bestTau > 1 && bestTau < maxLag)
    {
        float s0 = cmnd[bestTau - 1];
        float s1 = cmnd[bestTau];
        float s2 = cmnd[bestTau + 1];
        float denom = 2.0f * (2.0f * s1 - s2 - s0);
        if (std::abs (denom) > 1e-6f)
            refinedTau += (s2 - s0) / denom;
    }

    float detectedFreq = static_cast<float>(sampleRate) / refinedTau;
    outConfidence = juce::jlimit (0.0f, 1.0f, 1.0f - cmnd[bestTau]);

    float midiFloat = 69.0f + 12.0f * std::log2 (detectedFreq / 440.0f);
    int midiNote = static_cast<int>(std::round (midiFloat));

    if (midiNote < 21 || midiNote > 108)
        return -1;

    return midiNote;
}

void OneClicMIDIAudioProcessor::extractPolyphonicNotes (const float* samples, int numSamples,
                                                        double sampleRate, std::vector<int>& activeNotes,
                                                        int& outVelocity)
{
    activeNotes.clear();
    float sumSq = 0.0f;
    for (int i = 0; i < numSamples; ++i)
        sumSq += samples[i] * samples[i];
    float rms = std::sqrt (sumSq / static_cast<float>(numSamples));
    if (rms < 0.015f)
        return;

    outVelocity = juce::jlimit (35, 127, static_cast<int>(rms * 320.0f));

    // Scansione spettrale Goertzel sulle note da C2 (36) a C6 (84)
    const int minNote = 36;
    const int maxNote = 84;
    const int numNotes = maxNote - minNote + 1;
    std::vector<float> noteEnergies (numNotes, 0.0f);

    for (int n = 0; n < numNotes; ++n)
    {
        int midi = minNote + n;
        double freq = 440.0 * std::pow (2.0, (midi - 69) / 12.0);
        double omega = 2.0 * juce::MathConstants<double>::pi * freq / sampleRate;
        double coeff = 2.0 * std::cos (omega);
        double s0 = 0.0, s1 = 0.0, s2 = 0.0;

        for (int i = 0; i < numSamples; ++i)
        {
            double win = 0.5 * (1.0 - std::cos (2.0 * juce::MathConstants<double>::pi * i / (numSamples - 1)));
            s0 = samples[i] * win + coeff * s1 - s2;
            s2 = s1;
            s1 = s0;
        }
        double power = s1 * s1 + s2 * s2 - coeff * s1 * s2;
        noteEnergies[n] = static_cast<float>(std::sqrt (std::max (0.0, power)) / numSamples);
    }

    // Soppressione armonica (riduce l'energia dell'ottava +12 e quinta +19 per isolare le fondamentali dell'accordo)
    for (int n = 0; n < numNotes; ++n)
    {
        if (n + 12 < numNotes)
            noteEnergies[n + 12] = std::max (0.0f, noteEnergies[n + 12] - noteEnergies[n] * 0.45f);
        if (n + 19 < numNotes)
            noteEnergies[n + 19] = std::max (0.0f, noteEnergies[n + 19] - noteEnergies[n] * 0.25f);
    }

    float maxEnergy = 0.0f;
    for (float e : noteEnergies)
        maxEnergy = std::max (maxEnergy, e);

    if (maxEnergy < 0.002f)
        return;

    // Seleziona fino a 4 picchi principali dell'accordo
    std::vector<std::pair<float, int>> peaks;
    for (int n = 1; n < numNotes - 1; ++n)
    {
        if (noteEnergies[n] > noteEnergies[n - 1] &&
            noteEnergies[n] >= noteEnergies[n + 1] &&
            noteEnergies[n] > maxEnergy * 0.42f)
        {
            peaks.push_back ({ noteEnergies[n], minNote + n });
        }
    }

    std::sort (peaks.begin(), peaks.end(), [] (const auto& a, const auto& b) {
        return a.first > b.first;
    });

    for (size_t i = 0; i < std::min<size_t> (4, peaks.size()); ++i)
        activeNotes.push_back (peaks[i].second);

    std::sort (activeNotes.begin(), activeNotes.end());
}

bool OneClicMIDIAudioProcessor::convertAudioFileToMidi (const juce::File& audioFile, juce::File& outMidiFile)
{
    conversionProgress.store (0.05f);

    juce::AudioFormatManager formatManager;
    formatManager.registerBasicFormats();

    std::unique_ptr<juce::AudioFormatReader> reader (formatManager.createReaderFor (audioFile));
    if (reader == nullptr || reader->lengthInSamples <= 0)
    {
        lastStatusText = "FORMATO NON VALIDO";
        conversionProgress.store (0.0f);
        return false;
    }

    const int totalSamples = static_cast<int>(std::min<juce::int64> (reader->lengthInSamples, 44100 * 600));
    const double fileSampleRate = reader->sampleRate;

    juce::AudioBuffer<float> tempBuffer (static_cast<int>(reader->numChannels), totalSamples);
    reader->read (&tempBuffer, 0, totalSamples, 0, true, true);

    // Mixdown in Mono per l'analisi
    std::vector<float> mono (totalSamples, 0.0f);
    const int chCount = tempBuffer.getNumChannels();
    for (int ch = 0; ch < chCount; ++ch)
    {
        const float* chPtr = tempBuffer.getReadPointer (ch);
        for (int i = 0; i < totalSamples; ++i)
            mono[i] += chPtr[i] / static_cast<float>(chCount);
    }

    int mode = static_cast<int>(apvts.getRawParameterValue ("PRESET_ID")->load());
    const int frameSize = 2048;
    const int hopSize   = 512;
    const double frameTimeSec = static_cast<double>(hopSize) / fileSampleRate;

    std::vector<MidiNoteEvent> extractedEvents;

    if (mode == 3)
    {
        // MODALITÀ 4: DRUM LOOP -> MIDI (Kick = 36/C1, Snare = 38/D1, Hi-Hat = 42/F#1)
        float prevLowEnv = 0.0f, prevMidEnv = 0.0f, prevHighEnv = 0.0f;
        double lastKickTime = -1.0, lastSnareTime = -1.0, lastHatTime = -1.0;
        float lpState = 0.0f, hpState = 0.0f;

        for (int pos = 0; pos + hopSize < totalSamples; pos += hopSize)
        {
            float lowEnergy = 0.0f, midEnergy = 0.0f, highEnergy = 0.0f;
            for (int i = 0; i < hopSize; ++i)
            {
                float x = mono[pos + i];
                lpState = lpState + 0.08f * (x - lpState);
                float high = x - lpState;
                hpState = hpState + 0.45f * (high - hpState);
                float veryHigh = high - hpState;

                lowEnergy  += lpState * lpState;
                midEnergy  += hpState * hpState;
                highEnergy += veryHigh * veryHigh;
            }

            lowEnergy  = std::sqrt (lowEnergy / hopSize);
            midEnergy  = std::sqrt (midEnergy / hopSize);
            highEnergy = std::sqrt (highEnergy / hopSize);

            double tSec = static_cast<double>(pos) / fileSampleRate;

            if (lowEnergy > 0.05f && (lowEnergy - prevLowEnv) > 0.028f && (tSec - lastKickTime) > 0.09)
            {
                int vel = juce::jlimit (50, 127, static_cast<int>(lowEnergy * 340.0f));
                extractedEvents.push_back ({ 36, vel, tSec, 0.10 });
                lastKickTime = tSec;
            }
            if (midEnergy > 0.035f && (midEnergy - prevMidEnv) > 0.022f && (tSec - lastSnareTime) > 0.09)
            {
                int vel = juce::jlimit (45, 127, static_cast<int>(midEnergy * 380.0f));
                extractedEvents.push_back ({ 38, vel, tSec, 0.10 });
                lastSnareTime = tSec;
            }
            if (highEnergy > 0.018f && (highEnergy - prevHighEnv) > 0.012f && (tSec - lastHatTime) > 0.055)
            {
                int vel = juce::jlimit (40, 120, static_cast<int>(highEnergy * 500.0f));
                extractedEvents.push_back ({ 42, vel, tSec, 0.06 });
                lastHatTime = tSec;
            }

            prevLowEnv  = lowEnergy;
            prevMidEnv  = midEnergy;
            prevHighEnv = highEnergy;
            conversionProgress.store (0.1f + 0.75f * (static_cast<float>(pos) / totalSamples));
        }
    }
    else if (mode == 2)
    {
        // MODALITÀ 3: ACCORDI & SYNTH POLIFONICO
        std::map<int, std::pair<double, int>> activeMap; // midiNote -> (startTime, velocity)
        for (int pos = 0; pos + frameSize < totalSamples; pos += hopSize)
        {
            double tSec = static_cast<double>(pos) / fileSampleRate;
            std::vector<int> chordNotes;
            int vel = 90;
            extractPolyphonicNotes (mono.data() + pos, frameSize, fileSampleRate, chordNotes, vel);

            // Chiudi le note che non sono più attive
            for (auto it = activeMap.begin(); it != activeMap.end(); )
            {
                if (std::find (chordNotes.begin(), chordNotes.end(), it->first) == chordNotes.end())
                {
                    double dur = tSec - it->second.first;
                    if (dur >= frameTimeSec * 2.5)
                        extractedEvents.push_back ({ it->first, it->second.second, it->second.first, dur });
                    it = activeMap.erase (it);
                }
                else
                {
                    ++it;
                }
            }

            // Apri nuove note dell'accordo
            for (int n : chordNotes)
            {
                if (activeMap.find (n) == activeMap.end())
                    activeMap[n] = { tSec, vel };
            }

            conversionProgress.store (0.1f + 0.75f * (static_cast<float>(pos) / totalSamples));
        }

        double endTime = static_cast<double>(totalSamples) / fileSampleRate;
        for (const auto& kv : activeMap)
        {
            double dur = endTime - kv.second.first;
            if (dur >= frameTimeSec * 2.0)
                extractedEvents.push_back ({ kv.first, kv.second.second, kv.second.first, dur });
        }
    }
    else
    {
        // MODALITÀ MONOFONICHE: Melodia/Voce (0), Bassline/808 (1), Universal Auto-Detect (4)
        float minFreq = (mode == 1) ? 28.0f  : ((mode == 0) ? 75.0f   : 35.0f);
        float maxFreq = (mode == 1) ? 360.0f : ((mode == 0) ? 1400.0f : 1600.0f);

        int activeNote = -1;
        double noteStartSec = 0.0;
        int activeVel = 100;

        for (int pos = 0; pos + frameSize < totalSamples; pos += hopSize)
        {
            double tSec = static_cast<double>(pos) / fileSampleRate;
            float confidence = 0.0f;
            int detected = detectMonophonicMidiNote (mono.data() + pos, frameSize, fileSampleRate,
                                                     minFreq, maxFreq, confidence);

            float rms = 0.0f;
            for (int i = 0; i < hopSize; ++i)
                rms += mono[pos + i] * mono[pos + i];
            rms = std::sqrt (rms / hopSize);
            int vel = juce::jlimit (40, 127, static_cast<int>(rms * 340.0f));

            if (detected != activeNote)
            {
                if (activeNote >= 0)
                {
                    double dur = tSec - noteStartSec;
                    if (dur >= frameTimeSec * 2.0)
                        extractedEvents.push_back ({ activeNote, activeVel, noteStartSec, dur });
                }
                activeNote = detected;
                noteStartSec = tSec;
                activeVel = vel;
            }

            conversionProgress.store (0.1f + 0.75f * (static_cast<float>(pos) / totalSamples));
        }

        if (activeNote >= 0)
        {
            double dur = (static_cast<double>(totalSamples) / fileSampleRate) - noteStartSec;
            if (dur >= frameTimeSec * 2.0)
                extractedEvents.push_back ({ activeNote, activeVel, noteStartSec, dur });
        }
    }

    // Costruzione del file .MID Standard (480 ticks per quarto a 120 BPM => 960 ticks al secondo)
    juce::MidiMessageSequence sequence;
    sequence.addEvent (juce::MidiMessage::tempoMetaEvent (500000), 0.0); // 120 BPM
    const double ticksPerSecond = 960.0;

    for (const auto& ev : extractedEvents)
    {
        double startTick = ev.startTimeSec * ticksPerSecond;
        double endTick   = (ev.startTimeSec + ev.durationSec) * ticksPerSecond;

        sequence.addEvent (juce::MidiMessage::noteOn  (1, ev.midiNote, static_cast<juce::uint8>(ev.velocity)), startTick);
        sequence.addEvent (juce::MidiMessage::noteOff (1, ev.midiNote), endTick);
    }

    sequence.sort();
    sequence.updateMatchedPairs();

    juce::MidiFile midiFile;
    midiFile.setTicksPerQuarterNote (480);
    midiFile.addTrack (sequence);

    if (outMidiFile.existsAsFile())
        outMidiFile.deleteFile();

    juce::FileOutputStream outStream (outMidiFile);
    if (!outStream.openedOk() || !midiFile.writeTo (outStream))
    {
        lastStatusText = "ERRORE SALVATAGGIO";
        conversionProgress.store (0.0f);
        return false;
    }

    lastDetectedNoteCount.store (static_cast<int>(extractedEvents.size()));
    lastConvertedMidiPath = outMidiFile.getFullPathName();
    lastStatusText = "CREATO: " + outMidiFile.getFileName();
    conversionProgress.store (1.0f);
    return true;
}

void OneClicMIDIAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    const int numSamples = buffer.getNumSamples();
    if (buffer.getNumChannels() == 0 || numSamples == 0)
        return;

    const float* inL = buffer.getReadPointer (0);
    for (int i = 0; i < numSamples; ++i)
    {
        analysisRingBuffer[ringWritePos] = inL[i];
        ringWritePos = (ringWritePos + 1) % static_cast<int>(analysisRingBuffer.size());
    }

    float confidence = 0.0f;
    int detected = detectMonophonicMidiNote (analysisRingBuffer.data(),
                                             static_cast<int>(analysisRingBuffer.size()),
                                             currentSampleRate, 45.0f, 1200.0f, confidence);

    if (detected != currentLiveNote)
    {
        if (currentLiveNote >= 0)
            midiMessages.addEvent (juce::MidiMessage::noteOff (1, currentLiveNote), 0);

        if (detected >= 0)
            midiMessages.addEvent (juce::MidiMessage::noteOn (1, detected, static_cast<juce::uint8>(100)), 0);

        currentLiveNote = detected;
        liveDetectedMidiNote.store (detected);
    }
}

void OneClicMIDIAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    state.setProperty ("customLogoPath", customLogoPath, nullptr);
    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    copyXmlToBinary (*xml, destData);
}

void OneClicMIDIAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState (getXmlFromBinary (data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName (apvts.state.getType()))
    {
        auto tree = juce::ValueTree::fromXml (*xmlState);
        customLogoPath = tree.getProperty ("customLogoPath", "").toString();
        apvts.replaceState (tree);
    }
}

juce::AudioProcessorEditor* OneClicMIDIAudioProcessor::createEditor()
{
    return new OneClicMIDIAudioProcessorEditor (*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new OneClicMIDIAudioProcessor();
}
