#pragma once
#include <JuceHeader.h>

struct MidiNoteEvent
{
    int midiNote = 60;
    int velocity = 100;
    double startTimeSec = 0.0;
    double durationSec = 0.25;
};

class OneClicMIDIAudioProcessor : public juce::AudioProcessor
{
public:
    OneClicMIDIAudioProcessor();
    ~OneClicMIDIAudioProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "OneClicMIDI"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return true; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return static_cast<int>(presetNames.size()); }
    int getCurrentProgram() override { return currentPresetIndex; }
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override { return presetNames[index]; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    // Converte qualsiasi file WAV/AIFF/FLAC in un file .MID con 1 clic
    bool convertAudioFileToMidi (const juce::File& audioFile, juce::File& outMidiFile);

    juce::AudioProcessorValueTreeState apvts;
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    std::atomic<float> conversionProgress { 0.0f };
    std::atomic<int> lastDetectedNoteCount { 0 };
    std::atomic<int> liveDetectedMidiNote { -1 };

    juce::String lastConvertedMidiPath;
    juce::String lastStatusText { "CLICCA O TRASCINA WAV" };
    juce::String customLogoPath;

private:
    int detectMonophonicMidiNote (const float* samples, int numSamples, double sampleRate,
                                  float minFreq, float maxFreq, float& outConfidence);

    void extractPolyphonicNotes (const float* samples, int numSamples, double sampleRate,
                                 std::vector<int>& activeNotes, int& outVelocity);

    double currentSampleRate = 44100.0;
    int currentPresetIndex = 0;
    juce::StringArray presetNames;

    // Stato real-time per tracciamento MIDI live sul canale della DAW
    int currentLiveNote = -1;
    std::vector<float> analysisRingBuffer;
    int ringWritePos = 0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (OneClicMIDIAudioProcessor)
};
